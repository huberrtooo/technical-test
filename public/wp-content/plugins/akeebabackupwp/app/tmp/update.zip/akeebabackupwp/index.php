<?php
/**
 * @package    akeebabackupwp
 * @copyright  Copyright (c)2014-2023 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license    GNU GPL version 3 or later
 */

die;
